--CREATE
user = User(username='junho', email='example@gmail.com')
db.session.add(user)
db.session.commit()
        
--READ
SELECT * FROM users;
users = User.query.all()

SELECT * FROM users WHERE username='junho';
users = User.query.filter_by(username='junho').all()

SELECT * FROM users WHERE username='junho' LIMIT 1;
users = User.query.filter_by(username='junho').first()

-- NONE
miss = User.query.filter_by(username='ssafy').first()

-- get one by id
-- PK만 GET으로 가져올 수 있음.
SELECT * FROM users WHERE id=1;
user = User.query.get(1)

--LIKE
users = User.query.filter_by(User.email.like('%exam%')).all()
users = User.query.limit(1).offset(2).all()

--UPDATE
user = User.query.get(1)
user.username = 'ssafy'
db.session.commit()

--DELETE
user = User.query.get(1)
db.session.delete(user)
db.session.commit()