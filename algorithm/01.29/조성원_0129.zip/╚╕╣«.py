import sys
sys.stdin = open('회문_input.text')

test = int(input())

for tc in range(test):
    N, M = map(int, input().split())
    input_list=[""]*N

    for row in range(N):
        input_list[row]=input()

    for row in range(N):
        for column in range(N-M+1):
            for i in range(M//2+1):
                if input_list[row][column+i] != input_list[row][column+M-1-i]:
                    break
            else:
                print(f'#{tc+1} {"".join(input_list[row][column:column+M])}')
    else:
        for column in range(N):
            for row in range(N-M+1):
                for i in range(M//2+1):
                    if input_list[row + i][column] != input_list[row + M - 1 - i][column]:
                        break
                else:
                    print(f'#{tc + 1}', end=' ')
                    for i in range(M):
                        print(f'{input_list[row+i][column]}', end='')
                    print()